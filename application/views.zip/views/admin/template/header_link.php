<head>

  <meta charset="utf-8" />
  <title><?= $title ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link href="<?= base_url() ?>assets/admin/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <link href="<?= base_url() ?>assets/admin/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <link href="<?= base_url() ?>assets/admin/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
  <link href="<?= base_url() ?>assets/admin/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
  <link href="<?= base_url() ?>assets/admin/css/icons.min.css" rel="stylesheet" type="text/css" />
  <link href="<?= base_url() ?>assets/admin/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
  <script src="https://cdn.ckeditor.com/4.16.2/standard-all/ckeditor.js"></script>

  <script type="application/javascript">
    CKEDITOR.replace('editor1');
  </script>
  
  
  <style>
      @media (max-width: 991px){
    .card-body{
        overflow-x: scroll !important;
    }
}
  </style>

</head>