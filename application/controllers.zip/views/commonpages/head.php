<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title>SriMitra </title>
	<!-- <link rel="icon" href="<?= base_url(); ?>img/favicon.png" type="image/png"> -->
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/css/bootstrap.min.css" />
	<!-- animate CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/css/animate.css" />
	<!-- themify icon CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/vendors/themify_icons/themify-icons.css" />
	<!-- owl carousel CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/vendors/owl_carousel/css/owl.carousel.css" />
	<!-- flaticon CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/vendors/flatIcon/flaticon.css" />
	<!-- style CSS -->
	<link rel="stylesheet" href="<?= base_url(); ?>assets/css/style.css" />

</head>