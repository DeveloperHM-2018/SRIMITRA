<!doctype html>
<html lang="en">


<?php $this->load->view('admin/template/header_link'); ?>


<body data-topbar="colored">
    <div id="layout-wrapper">
        <?php $this->load->view('admin/template/header'); ?>
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid ">
                    <div class="page-title-box">
                        <div class="row ">
                            <div class="col-md-10">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="page-title">
                                        <h4 class="mb-0 font-size-18"> <button type="button" class="badge btn-warning" onclick="history.back();">Back</button> | <?= $title; ?></h4>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                
                            </div>
                        </div>
                    </div>
                    <div class="page-content-wrapper">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <section class=" container">
                                            <div class=" row">
                                                <div class="col-md-12 m-1 p-1" style="border: 1px solid grey;border-radius:10px;">
                                                    <h4>Entity Details</h4>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Name of Shop :</h5>
                                                    <?= $mar[0]['shop_name']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>State :</h5>
                                                    <?= $state[0]['state_name']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>City :</h5>
                                                    <?= $city[0]['name']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Pincode :</h5>
                                                    <?= $mar[0]['pincode']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Address :</h5>
                                                    <?= $mar[0]['address']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>GEO Link :</h5>
                                                    <?= $mar[0]['geo_code']; ?>
                                                </div>
                                                <div class="col-md-12 m-1 p-1" style="border: 1px solid grey;border-radius:10px;">
                                                    <h4>Merchant documents Details</h4>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Shop Act :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['shop_act'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Shop Pan :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['shop_pan'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Udyam Adhar :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['shop_pan'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Shop GST :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['shop_gst'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Shop Image :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['shop_img'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-12 m-1 p-1" style="border: 1px solid grey;border-radius:10px;">
                                                    <h4>Contact Info Details</h4>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Merchant Name :</h5>
                                                    <?= $mar[0]['m_name']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Number :</h5>
                                                    <?= $mar[0]['number']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Email :</h5>
                                                    <?= $mar[0]['email']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Pan :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['m_pan'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Adhar :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['m_adhar'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Merchant Photo :</h5>
                                                    <a href="<?= base_url() ?>uploads/merchant/<?= $mar[0]['m_photo'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                </div>
                                                <div class="col-md-12 m-1 p-1" style="border: 1px solid grey;border-radius:10px;">
                                                    <h4>Bank Details</h4>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Bank :</h5>
                                                    <?= $mar[0]['bank']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Account no :</h5>
                                                    <?= $mar[0]['acc_no']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>IFSC :</h5>
                                                    <?= $mar[0]['ifsc']; ?>
                                                </div>
                                                <div class="col-md-3">
                                                    <h5>Branch Address :</h5>
                                                    <?= $mar[0]['bank_address']; ?>
                                                </div> 
                                            </div> 
                                        </section> 
                                    </div>
                                </div>
                            </div> 
                        </div>  
                    </div> 
                </div>
                <!-- Container-fluid -->
            </div>
            <!-- End Page-content -->

        </div>
        <?php include 'template/footer_link.php'; ?>


</body>

</html>