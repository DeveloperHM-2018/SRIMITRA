<!doctype html>
<html lang="en">


<?php $this->load->view('admin/template/header_link'); ?>

<body data-topbar="colored">
    <div id="layout-wrapper">
        <?php $this->load->view('admin/template/header'); ?>

        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">
                    <div class="page-title-box">
                        <div class="row">

                            <div class="col-md-10">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <div class="page-title">
                                        <h4 class="mb-0 font-size-18"> <button type="button" class="badge btn-warning" onclick="history.back();">Back</button> | <?= $title; ?> Edit</h4>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class=" d-flex align-items-center justify-content-between">
                                    <a href="<?= base_url('admin_Dashboard/merchant') ?>" class="btn btn-light"> <?= $title ?> List</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-wrapper">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form method="post" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-md-3">
                                                    <label class="form-label">Shop Name</label>
                                                    <input type="text" class="form-control" name="shop_name" value="<?= $march[0]['shop_name']  ?>" />
                                                </div>

                                                <div class="col-md-3">
                                                    <label class="form-label">State</label>
                                                    <select class="form-control" name="state" id="state">
                                                        <option value="">Select state </option>
                                                        <?php
                                                        if ($state_list) {
                                                            foreach ($state_list as $state) {
                                                        ?>
                                                                <option value="<?= $state['state_id'] ?>" <?= (($march[0]['state'] == $state['state_id']) ? 'selected' : '') ?>><?= $state['state_name'] ?></option>
                                                        <?php

                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">City</label>
                                                    <select name="city" class="form-control" id="city">
                                                        <option value="<?= $city[0]['id'] ?>"><?= $city[0]['name'] ?></option>
                                                    </select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Pincode</label>
                                                    <input type="text" class="form-control" name="pincode" value="<?= $march[0]['pincode']  ?>" />
                                                </div>



                                                <div class="col-md-3">
                                                    <label class="form-label">address</label>
                                                    <input type="text" class="form-control" name="address" value="<?= $march[0]['address']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Address GEO Codeing</label>
                                                    <input type="text" class="form-control" name="geo_code" value="<?= $march[0]['geo_code']  ?>" />
                                                </div>

                                                <h5> </br>Document Section <span style="color:#9F0B0B;">(Please uploads small than 5MB File)</span></h5>
                                                <div class="col-md-3">
                                                    <label class="form-label">Shop Act</label>
                                                    <input type="file" class="form-control" name="shop_act_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_act" value="<?= $march[0]['shop_act']  ?>" />
                                                    <?php
                                                    if ($march[0]['shop_act'] != '' && $march[0]['shop_act'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_act'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Shop PAN</label>
                                                    <input type="file" class="form-control" name="shop_pan_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_pan" value="<?= $march[0]['shop_pan']  ?>" />
                                                    <?php
                                                    if ($march[0]['shop_pan'] != '' && $march[0]['shop_pan'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_pan'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>

                                                <div class="col-md-3">
                                                    <label class="form-label">Udyam aadhar</label>
                                                    <input type="file" class="form-control" name="shop_adhar_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_adhar" value="<?= $march[0]['shop_adhar'] ?>" />
                                                    <?php
                                                    if ($march[0]['shop_adhar'] != '' && $march[0]['shop_adhar'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_adhar'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>

                                                <div class="col-md-3">
                                                    <label class="form-label">Udyam aadhar Back</label>
                                                    <input type="file" class="form-control" name="shop_adhar_back_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_adhar_back" value="<?= $march[0]['shop_adhar_back'] ?>" />
                                                    <?php
                                                    if ($march[0]['shop_adhar'] != '' && $march[0]['shop_adhar'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_adhar'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>


                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Shop GST</label>
                                                    <input type="file" class="form-control" name="shop_gst_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_gst" value="<?= $march[0]['shop_gst']  ?>" />
                                                    <?php
                                                    if ($march[0]['shop_gst'] != '' && $march[0]['shop_gst'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_gst'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Shop Image </label>
                                                    <input type="file" class="form-control" name="shop_img_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="shop_img" value="<?= $march[0]['shop_img']  ?>" />
                                                    <?php
                                                    if ($march[0]['shop_img'] != '' && $march[0]['shop_img'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['shop_img'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>

                                                <h5> <br> Merchant Details </h5>

                                                <div class="col-md-3">
                                                    <label class="form-label">Merchant Name</label>
                                                    <input type="text" class="form-control" name="m_name" value="<?= $march[0]['m_name']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Number</label>
                                                    <input type="text" class="form-control" name="number" value="<?= $march[0]['number']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Email</label>
                                                    <input type="text" class="form-control" name="email" value="<?= $march[0]['email']  ?>" />
                                                </div>


                                                <div class="col-md-3">
                                                    <label class="form-label">Pan</label>
                                                    <input type="file" class="form-control" name="m_pan_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="m_pan" value="<?= $march[0]['m_pan']  ?>" />

                                                    <?php
                                                    if ($march[0]['m_pan'] != '' && $march[0]['m_pan'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['m_pan'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Merchant Adhar</label>
                                                    <input type="file" class="form-control" name="m_adhar_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="m_adhar" value="<?= $march[0]['m_adhar']  ?>" />
                                                    <?php
                                                    if ($march[0]['m_adhar'] != '' && $march[0]['m_adhar'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['m_adhar'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>


                                                <div class="col-md-3">
                                                    <label class="form-label">Merchant Adhar back</label>
                                                    <input type="file" class="form-control" name="m_aadhar_back_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="m_aadhar_back" value="<?= $march[0]['m_aadhar_back']  ?>" />
                                                    <?php
                                                    if ($march[0]['m_aadhar_back'] != '' && $march[0]['m_aadhar_back'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['m_aadhar_back'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                </div>



                                                <div class="col-md-3">
                                                    <label class="form-label"> Merchant Photo</label>
                                                    <input type="file" class="form-control" name="m_photo_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="m_photo" value="<?= $march[0]['m_photo']  ?>" />
                                                    <?php
                                                    if ($march[0]['m_photo'] != '' && $march[0]['m_photo'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['m_photo'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                </div>

                                                <h5>
                                                    <br>Account Details
                                                </h5>
                                                <div class="col-md-3">
                                                    <label class="form-label">Bank</label>
                                                    <input type="text" class="form-control" name="bank" value="<?= $march[0]['bank']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Account Number</label>
                                                    <input type="text" class="form-control" name="acc_no" value="<?= $march[0]['acc_no']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Cancel Check Image</label>
                                                    <input type="file" class="form-control" name="cancel_check_temp" accept="image/*,.pdf" />
                                                    <p style="color:#9F0B0B;"> Maximum File Size Limit is 5MB. </p>
                                                    <input type="hidden" class="form-control" name="cancel_check" value="<?= $march[0]['cancel_check']  ?>" />
                                                    <?php
                                                    if ($march[0]['cancel_check'] != '' && $march[0]['cancel_check'] != 0) {
                                                    ?>
                                                        <a href="<?= base_url() ?>uploads/merchant/<?= $march[0]['cancel_check'];  ?>" target="_blank" class="btn btn-info">View</a>
                                                    <?php
                                                    }
                                                    ?>
                                                     
                                                </div>



                                                <div class="col-md-3">
                                                    <label class="form-label">IFSC</label>
                                                    <input type="text" class="form-control" name="ifsc" value="<?= $march[0]['ifsc']  ?>" />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="form-label">Bank address</label>
                                                    <input type="text" class="form-control" name="bank_address" value="<?= $march[0]['bank_address']  ?>" />


                                                </div>

                                            </div>

                                            <div class="mb-0">
                                                <div class="col-md-3">
                                                    <br>
                                                    <button type="submit" class="btn btn-primary waves-effect waves-light me-1">
                                                        Submit
                                                    </button>

                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

        </div>
        <?php include 'template/footer_link.php'; ?>


</body>

</html>


<script>
    $(document).on('change', '#state', function() {

        var state = $(this).val();
        // console.log(state);
        $.ajax({
            method: "POST",
            url: "<?= base_url('Admin_Dashboard/getcity') ?>",
            data: {
                state: state
            },
            success: function(response) {
                // console.log(response);
                $('#city').html(response);
            }
        });
    });
</script>