<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <p class="text-left mb-0">Copyright <i class="far fa-copyright"></i> <span id="copyright-year">Inventory Management</span> . All rights reserved</p>
            </div>
            <div class="col-md-6 d-none d-md-block">
                <p class="text-right mb-0">Made with <i class="fa fa-heart text-danger"></i> WAT</p>
            </div>
        </div>
    </div>
</div>